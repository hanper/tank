<?php
include ("includes/closeDB.php");        
?>
<footer>
    <div class="">
        <img class="img img-responsive" src="Images/bottom_background.png" alt="All Rights Reserved."/>
    </div>
</footer>
</body>
</html>
