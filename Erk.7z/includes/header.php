<?php 
 require_once ("includes/session.php");
 if(!isset($_SESSION['userid'])){   //Холбогдоогүй бол ХОЛБОХ хуудас уруу шилжих.
    header("Location: logon.php");
    }
 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Тавтай морилно уу.</title>

<link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="/css/main.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1"> 
</head>
    
<body>
<!--Хамгийн дээд талын цагаан ЭХЛЭЛ-->
<!--Том болоод дунд үед харагдаж бусад үед алга болно.-->
<div class="navbar top visible-md visible-lg">
    <div class="container">
    <div class="col-md-12">
        <div class="collapse navbar-collapse" id="navbar-collapse2">
          <ul class="nav navbar-nav navbar-right green">
             <?php 
                if (logged_on()) {
                    echo "<li><p>Тавтай морил, <strong>{$_SESSION['username']}</strong><p></li>";
                    echo '<li><a href="#">Мэдээлэл засах</a></li>';
                    echo '<li><a href="/logoff.php">Гарах</a></li>';
                }
                else {
                    echo '<li><a href="/logon.php">Нэвтрэх</a></li>';
                    echo '<li><a href="/register.php">Бүртгүүлэх</a></li>';
                }
             ?>
           </ul>
        </div>	
     </div>
     </div>	
</div>
<!--Хамгийн дээд талын цагаан ТӨГСГӨЛ-->
<!--Цэнхэр толгой ЭХЛЭЛ-->
<nav class="navbar header navbar-default">
    <div class="container">
 	<div class="col-md-12">
        <div class="navbar-header">
          
          <a href="#" class="navbar-brand"><img src="/images/logo.png" alt="Навч" /></a>
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse1">
            <i class="fa fa-search"></i>
          </button>
      
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse1">
          <ul class="nav navbar-nav navbar-left">
             <li>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-home"></i> Home <small><i class="fa fa-down"></i></small></a>
                  <ul class="nav dropdown-menu">
                      <li><a href="#"><i class="fa fa-user" style="color:#1111dd;"></i> Profile</a></li>
                      <li><a href="#"><i class="fa fa-dashboard" style="color:#0000aa;"></i> Dashboard</a></li>
                      <li><a href="#"><i class="fa fa-inbox" style="color:#11dd11;"></i> Pages</a></li>
                      <li class="nav-divider"></li>
                      <li><a href="#"><i class="fa fa-cog" style="color:#dd1111;"></i> Settings</a></li>
                      <li><a href="#"><i class="fa fa-plus"></i> More..</a></li>
                  </ul>
             
             </li>
             <li>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i></a>
                <ul class="dropdown-menu">
                  <li><a href="#"><span class="badge pull-right">40</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">2</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">0</span>Link</a></li>
                  <li><a href="#"><span class="label label-info pull-right">1</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">13</span>Link</a></li>
                </ul>
             </li>
            
            <?php
                if (logged_on())
                {
                    if (is_admin())
                    {
                        echo '<li><a href="/users.php">Хэрэглэгчид</a></li>';
                        echo '<li><a href="/mp3player.php">Дуу тоглуулагч</a></li>';
                        echo '<li><a href="/uploadmp3.php">Дуу оруулах</a></li>';
                        echo '<li><a href="/medias.php">Дуут мэдээ</a></li>';
                        echo '<li><a href="/posts.php">Мэдээ</a></li>';
                        echo '<li><a href="/categories.php">Категoри</a></li>';
                        echo '<li><a href="/banners.php">Зураг</a></li>';
                    }
                }
            ?>
           </ul>

            <form class="navbar-form pull-right header-search">
              <div class="input-group" style="max-width:470px;">
                <input type="text" class="form-control" placeholder="Хайх" name="srch-term" id="srch-term">
                <div class="input-group-btn">
                  <button class="btn btn-default btn-primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
              </div>
          </form>
        </div>	
     </div>
     </div>	
</nav>
<!--Цэнхэр толгой ТӨГСГӨЛ-->