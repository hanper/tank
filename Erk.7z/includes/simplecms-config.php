<?php
    define('DB_NAME', 'simplecms586');
    define('DB_USER', 'simplecmsuser586');
    define('DB_PASSWORD', 'DR%h?y75[1&g');
    define('DB_HOST', 'localhost');

    define('DEFAULT_ADMIN_USERNAME', 'admin');
    define('DEFAULT_ADMIN_PASSWORD', '123asd123');
?>