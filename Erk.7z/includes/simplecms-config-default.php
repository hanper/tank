<?php
    define('DB_NAME', 'beta2015');
    define('DB_USER', 'beta2015');
    define('DB_PASSWORD', '2015beta');
    define('DB_HOST', 'gewoozeecom2.ipagemysql.com');

    define('DEFAULT_ADMIN_USERNAME', 'admin');
    define('DEFAULT_ADMIN_PASSWORD', 'adminuseradminuser');
?>