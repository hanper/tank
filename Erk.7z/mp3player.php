<?php 
    require_once ("Includes/session.php");
    require_once ("Includes/simplecms-config.php"); 
    require_once ("Includes/connectDB.php");
    include("Includes/header.php");

$idList = array();
$titleList = array();
$pathList = array();

    $statement = $databaseConnection->prepare("SELECT id, title, path FROM medias") ;
    $statement->execute();

    if($statement->error) {
        die("Database query failed: " . $statement->error);
    }

    $statement->bind_result($idItem, $titleItem, $pathItem);
    while($statement->fetch()) {
        array_push($idList, $idItem);
        array_push($titleList, $titleItem);
        array_push($pathList, $pathItem);
    }
?>

<div id="main">
    Separate PHP
    <ul>
        <?php 
            for($i = 0; $i < count($idList); $i++) {
                echo "<li>$titleList[$i] ----- <audio controls><source src=\"$pathList[$i]\" type=\"audio/mpeg\">Your browser does not support the audio element.</audio></li>";
            }
        ?>
    </ul>
    
    
    <!--All in one PHP
    <ul>
        <?php
            $statement = $databaseConnection->prepare("SELECT id, title, path FROM medias");
            $statement->execute();

            if($statement->error)
            {
                die("Database query failed: " . $statement->error);
            }

            $statement->bind_result($id, $title, $path);
            while($statement->fetch())
            {
                echo "<li>$title ----- <audio controls><source src=\"$path\" type=\"audio/mpeg\">Your browser does not support the audio element.</audio></li>";
            }
        ?>
    </ul>-->
</div>

<?php include ("Includes/footer.php"); ?>