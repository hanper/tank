<?php
require_once ("Includes/session.php");
require_once ("Includes/simplecms-config.php");
require_once ("Includes/connectDB.php");
include("Includes/header.php");
confirm_is_admin();

$categoryId = null;
$name = null;
$parentId = null;
$isHeader = NULL;
if(isset($_GET['id'])) {
    $categoryId = $_GET['id'];
    $query = "SELECT name, parent_id, is_header FROM categories WHERE id = ?";
    $statement = $databaseConnection->prepare($query);
    $statement->bind_param('d', $categoryId);
    $statement->execute();
    $statement->store_result();

    if ($statement->error) {
        die('Database query failed: ' . $statement->error);
    }

    if ($statement->num_rows == 1) {
        $statement->bind_result($name, $parentId, $isHeader);
        $statement->fetch();
    } 
    else {
        header("Location: index.php");
    }
}
else if (isset($_POST['submit'])) {
    $categoryId = $_POST['categoryId'];
    $name = $_POST['name'];
    $parentId = $_POST['parentId'];
    $isHeader = $_POST['isHeader'];
    $query = "UPDATE categories SET name = ?, parent_id = ?, is_header = ? WHERE id = ?";

    $statement = $databaseConnection->prepare($query);
    $statement->bind_param('sddd', $name, $parentId, $isHeader, $categoryId);
    $statement->execute();
    $statement->store_result();

    if ($statement->error) {
        die('Database query failed: ' . $statement->error);
    }

    $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
    if ($creationWasSuccessful) {
        header ("Location: categories.php");
    } 
    else {
        echo 'Failed to edit category';
    }
}
else
{
    header ("Location: categories.php");
}
?>
<div id="main">

    <h1>Edit Category</h1>
    <form action="editcategory.php" method="post">
            <fieldset>
                <legend>Edit Category</legend>
                <ol>
                    <li>
			            <input type="hidden" id="categoryId" name="categoryId" value="<?php echo $categoryId; ?>" />
                        <input type="text" name="name" value="<?php echo $name; ?>" id="name" />
                        <select id="parentId" name="parentId">
                            <?php
                                if($parentId > 0) {
                                    echo "<option value=\"$parentId\">$parentId</option\n";                               
                                } 
                                else {
                                    echo "<option value=\"0\">--Select Category--</option>\n";

                                }
                            ?>
                           
                            <?php
                                $statement = $databaseConnection->prepare("SELECT id, name FROM categories");
                                $statement->execute();

                                if($statement->error)
                                {
                                    die("Database query failed: " . $statement->error);
                                }

                                $statement->bind_result($id, $name);
                                while($statement->fetch())
                                {
                                    echo "<option value=\"$id\">$name</option>\n";
                                }
                            ?>
                        </select>
                        
                        <input type="checkbox" name="isHeader" value="1" id="isHeader" <?php echo ($isHeader==1 ? 'checked' : '');?>/>
                    </li>

                </ol>
                <input type="submit" name="submit" value="Submit" />
                <p>
                    <a href="categories.php">Cancel</a>
                </p>
        </fieldset>
    </form>
</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php include ("Includes/footer.php"); ?>

