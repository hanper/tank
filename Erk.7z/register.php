<?php 
    require_once ("Includes/simplecms-config.php"); 
    require_once  ("Includes/connectDB.php");

    if (isset($_POST['submit'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $birthday = $_POST['birthday'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $church = $_POST['church'];
        $cellphone = $_POST['cellphone'];
        $comment = $_POST['comment'];
        $isActive = 0; //need permission from ADMIN
        
        //echo  " $username, $password, $firstname, $lastname, $birthday, $email, $gender, $church, $cellphone, $comment, $isActive";

        $query = "INSERT INTO users (username, password, firstname, lastname, birthday, email, gender, church, cellphone, comment, is_active)";
        $query .= " VALUES (?, SHA(?), ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('ssssssssssd', $username, $password, $firstname, $lastname, $birthday, $email, $gender, $church, $cellphone, $comment, $isActive);
        $statement->execute();
        $statement->store_result();

        $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
        if ($creationWasSuccessful)
        {
            $userId = $statement->insert_id;

            $addToUserRoleQuery = "INSERT INTO users_in_roles (user_id, role_id) VALUES (?, ?)";
            $addUserToUserRoleStatement = $databaseConnection->prepare($addToUserRoleQuery);

            // TODO: Extract magic number for the 'user' role ID.
            $userRoleId = 2;
            $addUserToUserRoleStatement->bind_param('dd', $userId, $userRoleId);
            $addUserToUserRoleStatement->execute();
            $addUserToUserRoleStatement->close();

            header ("Location: logon.php");
        }
        else
        {
            echo "Failed registration";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Бүртгүүлэх</title>
    <link href="/Styles/main.css" rel="stylesheet" type="text/css" />
    <link href="/Styles/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="login-logo">
                <img src="Images/logo_login.png" alt="WELCOME"/>
            </div>
            <form action="register.php" method="post" class="form-horizontal">
                <div class="form-group">
                    <label class="control-label col-xs-3" for="username">Нэвтрэх нэр:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="text" class="form-control" id="username" placeholder="Нэвтрэх нэр" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="password">Нууц үг:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="password" class="form-control" id="password" placeholder="Нууц үг:" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="lastname">Овог:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="text" class="form-control" id="lastname" placeholder="Овог" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="firstname">Нэр:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="text" class="form-control" id="firstname" placeholder="Нэр" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="birthday">Төрсөн өдөр:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="date" id="birthday" class="form-control" min="1900-01-01" max="2010-01-01"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="password">Цахим шуудан:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="email" class="form-control" id="email" placeholder="Цахим шуудан" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="gender">Хүйс:</label>
                    <div class="col-xs-9 col-md-6">
                        <select id="gender" name="gender" class="form-control">
                            <option value="0">Хүйс</option>
                            <option value="Em">Эмэгтэй</option>
                            <option value="Er">Эрэгтэй</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="church">Сүм:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="text" class="form-control" id="church" placeholder="Сүм" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="cellphone">Утас:</label>
                    <div class="col-xs-9 col-md-6">
                        <input type="text" class="form-control" id="cellphone" placeholder="Утас" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-3" for="comment">Нэмэлт:</label>
                    <div class="col-xs-9 col-md-6">
                        <textarea name="comment" class="form-control" id="comment" rows="10" placeholder="Нэмэлт"></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-offset-3 col-xs-9">
                        <button type="submit" class="btn btn-default">Батлах</button>
                        <a href="logon.php" class="btn btn-default">Цуцлах</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>