<?php 
    require_once ("includes/simplecms-config.php"); 
    require_once  ("includes/connectDB.php");
    include("includes/header.php");

     $selectedCatId = getOnHomeCat();

     $selectedCatTitle = get_category($selectedCatId);
?>
<div class="container home">
    <div class="row">
        <div class="col-md-3 news-bar">
            <div class="news-header col-md-12">
                <h4><span style="color: #2a9e97;">ШИНЭ </span>МЭДЭЭ МЭДЭЭЛЭЛ</h4>
                <a href="">&#10148; Дэлгэрэнгүй</a>
            </div>
            <div class="news-list col-md-12">
                <ul class="news-thumbnail">
                    <?php
                        $statement = $databaseConnection->prepare("SELECT id, title, thumbnail, created_date FROM posts WHERE is_active = 1 ORDER BY created_date DESC LIMIT 0,5");
                        $statement->execute();

                        if($statement->error) {
                            die("Database query failed: " . $statement->error);
                        }

                        $statement->bind_result($postId, $title, $thumbnail, $createdDate);
                        while($statement->fetch()) {
                            echo "<li><img src='$thumbnail' /><span>$createdDate</span><a href='/editpost.php?id=$postId'>$title</a></li>\n";
                        }
                    ?>
                </ul>
            </div>
        </div>
        <div class="col-md-7 main-img-box"></div>
        <div class="col-md-2">
            <div class="row right-sidebar">
                <div class="col-md-12 profile-box">
                    <h4><?php 
                            if (logged_on()) {
                                echo "<strong>{$_SESSION['username']}</strong>,<br>тавтай морил";
                            }
                         ?>
                    </h4>
                    <div class="profile-links">
                        <?php
                            echo '<a href="#">Мэдээлэл засах</a> | <a href="/logoff.php">Гарах</a>';
                        ?>
                    </div>
                </div>
                <div class="col-md-12 banner-box">
                    <h1 style="color: white; margin: 50px 30px 40px 30px ;">Banner</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="row content-comment-list">
        <div class="col-md-6"style="min-height: 200px; box-shadow:  10px 0px 5px #888888;">
            <h2><?php echo $selectedCatTitle?></h2>
            <hr>

            <?php
               
                
                $query = "SELECT id, title, thumbnail, created_date FROM posts WHERE category_id = ? AND is_active = 1";
                $statement = $databaseConnection->prepare($query);
                $statement->bind_param('d', $selectedCatId);
                $statement->execute();
                $statement->store_result();

                if ($statement->error) {
                    die('Database query failed: ' . $statement->error);
                }

                if ($statement->num_rows == 1) {
                    $statement->bind_result($id, $title, $thumbnail, $createdDate);
                    while($statement->fetch()) {
                        echo "id=====" . $id . " name: ::::::::::::: " . $title . "<br>";
                    }
                }                 

            ?>
        </div>
        <div class="col-md-6" style=" min-height: 200px;"></div>
    </div>
</div>

<?php
    include("Includes/footer.php");
?>