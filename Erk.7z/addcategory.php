<?php 
    require_once ("Includes/session.php");
    require_once ("Includes/simplecms-config.php"); 
    require_once ("Includes/connectDB.php");
    include("Includes/header.php"); 
    confirm_is_admin();

    if (isset($_POST['submit']))
    {
        $name = $_POST['name'];
        $query = "INSERT INTO categories (name) VALUES (?)";

        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('s', $name);
        $statement->execute();
        $statement->store_result();

        if ($statement->error)
        {
            die('Database query failed: ' . $statement->error);
        }

        $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
        if ($creationWasSuccessful)
        {
            header ("Location: categories.php");
        }
        else
        {
            echo 'Failed adding new category';
        }
    }
?>
<div id="main">
    <h2>Add Category</h2>
        <form action="addcategory.php" method="POST">
            <fieldset>
            <legend>Add Category</legend>
            <ol>
                <li>
                    <label for="name">Name:</label> 
                    <input type="text" name="name" value="" id="name" />
                </li>
            </ol>
            <input type="submit" name="submit" value="Submit" />
            <p>
                <a href="index.php">Cancel</a>
            </p>
        </fieldset>
    </form>
</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php include ("Includes/footer.php"); ?>

