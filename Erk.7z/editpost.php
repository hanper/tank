<?php
require_once ("Includes/session.php");
require_once ("Includes/simplecms-config.php");
require_once ("Includes/connectDB.php");
include("Includes/header.php");
confirm_is_admin();

    $postId = NULL;
    $title = NULL;
    $thumbnail = NULL;
    $content = NULL;
    $categoryId = NULL;
    $createdDate = NULL;
    $isActive = NULL;

    if(isset($_GET['id'])) {
        $postId = $_GET['id'];

        $query = "SELECT title, thumbnail, content, category_id, is_active FROM posts WHERE id = ?";
        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('d', $postId);
        $statement->execute();
        $statement->store_result();

        if ($statement->error) {
            die('Database query failed: ' . $statement->error);
        }

        if ($statement->num_rows == 1) {
            $statement->bind_result($title, $thumbnail, $content, $categoryId, $isActive);
            $statement->fetch();
        } 
        else {
            header("Location: index.php");
        }
    }
    else if (isset($_POST['submit'])) {
        $postId = $_POST['postId'];
        $title = $_POST['title'];
        $thumbnail = $_POST['thumbnail'];
        $content = $_POST['content'];
        $categoryId = $_POST['categoryId'];
        $createdDate = date('Y-m-d H:i:s'); //current date
        $isActive = $_POST['isActive'];
        
        $query = "UPDATE posts SET title = ?, thumbnail = ?, content = ?, category_id = ?, created_date = ?, is_active = ? WHERE id = ?";

        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('sssdsdd', $title, $thumbnail, $content, $categoryId, $createdDate, $isActive, $postId);
        $statement->execute();
        $statement->store_result();

        if ($statement->error) {
            die('Database query failed: ' . $statement->error);
        }

        $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
        if ($creationWasSuccessful) {
            header ("Location: posts.php");
        } 
        else {
            echo 'Failed to edit post';
        }
    }
    else {
        header ("Location: posts.php");
    }
?>
<div id="main">

    <h1>Edit Post</h1>
    <form action="editpost.php" method="post">
            <fieldset>
                <legend>Edit Post</legend>
                <ol>
                    <li>
			            <input type="hidden" id="postId" name="postId" value="<?php echo $postId; ?>" />
                    </li>
                    <li>
                        <label for="title">title:</label> 
                        <input type="text" name="title" value="<?php echo $title; ?>" id="title" />
                    </li>
                    <li>
                        <label for="thumbnail">thumbnail:</label> 
                        <textarea name="thumbnail" id="thumbnail" rows="10"><?php echo $thumbnail; ?></textarea>
                    </li>
                    <li>
                        <label for="content">content:</label> 
                        <textarea name="content" id="content" rows="10"><?php echo $content; ?></textarea>
                    </li>
                    <li>
                        <label for="categoryId">categoryId:</label> 
                        <select name="categoryId" id="categoryId" >
                            <option value="<?php echo $categoryId; ?>"><?php echo get_category($categoryId); ?></option>
                            <?php
                                $statement = category_tree();
                                $statement->bind_result($tempId, $tempName);
                                while($statement->fetch()) {
                                    echo "<option value=\"$tempId\">$tempName</option>";
                                }
                            ?>
                        </select>
                    </li>
                    <li>
                        <label for="isActive">isActive:</label> 
                        <input type="checkbox" name="isActive" value="1" id="isActive" <?php echo ($isActive==1 ? 'checked' : '');?> />
                    </li>
                </ol>
                <input type="submit" name="submit" value="Submit" />
                <p>
                    <a href="posts.php">Cancel</a>
                </p>
        </fieldset>
    </form>
</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php include ("Includes/footer.php"); ?>

