<?php 
    require_once ("includes/session.php"); 
    require_once ("includes/simplecms-config.php"); 
    require_once  ("includes/connectDB.php");
    include("includes/header.php"); 
?>

<div id="main">
    <a href="addpost.php">ADD post</a>
    <ul>
        <?php
            $statement = $databaseConnection->prepare("SELECT id, title, thumbnail, content, category_id, created_date, is_active FROM posts");
            $statement->execute();

            if($statement->error) {
                die("Database query failed: " . $statement->error);
            }

            $statement->bind_result($postId, $title, $thumbnail, $content, $categoryId, $createdDate, $isActive);
            while($statement->fetch()) {
                echo "<li><a href=\"/editpost.php?id=$postId\">$title</a> --- $categoryId :::: $createdDate</li>\n";
            }
        ?>
    </ul>

</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php 
    include ("Includes/footer.php");
 ?>