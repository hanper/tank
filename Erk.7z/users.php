<?php 
    require_once ("Includes/session.php"); 
    require_once ("Includes/simplecms-config.php"); 
    require_once  ("Includes/connectDB.php");
    include("Includes/header.php"); 
?>

<div id="main">
    <ul>
        <?php
            $statement = $databaseConnection->prepare("SELECT id, username, is_active FROM users");
            $statement->execute();

            if($statement->error)
            {
                die("Database query failed: " . $statement->error);
            }

            $statement->bind_result($userId, $username, $isActive);
            while($statement->fetch())
            {
                if($isActive) {
                    $isChecked = "checked";
                    $action = "deactivate";
                } else {
                    $isChecked = "";
                    $action = "activate";
                }
                
                echo "<li>
                        <a href=\"/edituser.php?id=$userId\">$username</a>
                        <input type=\"checkbox\" name=\"isActive\" value=\"1\" id=\"isActive\" $isChecked disabled/>
                        <a href=\"user.php?id=$userId&action=$action \">$action</a>
                      </li>\n";
            }
        ?>
    </ul>

</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php 
    include ("Includes/footer.php");
 ?>