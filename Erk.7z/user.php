<?php
    require_once ("Includes/session.php");
    require_once ("Includes/simplecms-config.php");
    require_once ("Includes/connectDB.php");
    include("Includes/header.php");
    confirm_is_admin();

    $userId = NULL;
    $username = NULL;
    $firstname = NULL;
    $lastname = NULL;
    $birthday = NULL;
    $email = NULL;
    $gender = NULL;
    $church = NULL;
    $cellphone = NULL;
    $comment = NULL;
    $isActive = NULL;

    if(isset($_GET['id'])) {
        $userId = $_GET['id'];
    
        $query = "SELECT username, firstname, lastname, birthday, email, gender, church, cellphone, comment, is_active FROM users WHERE id = ?";
        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('d', $userId);
        $statement->execute();
        $statement->store_result();

        if ($statement->error) {
            die('Database query failed: ' . $statement->error);
        }

        if ($statement->num_rows == 1) {
            $statement->bind_result($username, $firstname, $lastname, $birthday, $email, $gender, $church, $cellphone, $comment, $isActive);
            $statement->fetch();
        }
        else {
            header("Location: index.php");
        }
    }
    else if (isset($_POST['submit'])) {
        $userId = $_POST['userId'];
        $username = $_POST['username'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $birthday = $_POST['birthday'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $church = $_POST['church'];
        $cellphone = $_POST['cellphone'];
        $comment = $_POST['comment'];
        $isActive = $_POST['isActive'];

        $query = "UPDATE users SET username = ?, firstname = ?, lastname = ?, birthday = ?, email = ?, gender = ?, church = ?, cellphone = ?, comment = ?, is_active = ? WHERE id = ?";

        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('sssssssssdd', $username, $firstname, $lastname, $birthday, $email, $gender, $church, $cellphone, $comment, $isActive, $userId);
        $statement->execute();
        $statement->store_result();

        if ($statement->error) {
            die('Database query failed: ' . $statement->error);
        }

        $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
        if ($creationWasSuccessful) {
            header ("Location: users.php");
        }
        else {
            echo 'Failed to edit user';
        }
    }
    else {
        header ("Location: users.php");
    }
?>
<div id="main">

    <h1>Edit User</h1>
    <form action="user.php" method="post">
            <fieldset>
                <legend>Edit User</legend>
                <ol>
                    <li><input type="hidden" id="userId" name="userId" value="<?php echo $userId; ?>" /></li>
                    <li>
                        <label for="username">Username:</label> 
                        <input type="text" name="username" value="<?php echo $username; ?>" id="username" />
                    </li>
                    <li>
                        <label for="firstname">firstname:</label>
                        <input type="text" name="firstname" value="<?php echo $firstname; ?>" id="firstname" />
                    </li>
                    <li>
                        <label for="lastname">lastname:</label>
                        <input type="text" name="lastname" value="<?php echo $lastname; ?>" id="lastname" />
                    </li>
                    <li>
                        <label for="birthday">birthday:</label>
                        <input type="date" name="birthday" value="<?php echo $birthday; ?>" id="birthday" min="1900-01-01" max="2010-01-01"/>
                    </li>
                    <li>
                        <label for="email">email:</label>
                        <input type="email" name="email" value="<?php echo $email; ?>" id="email" />
                    </li>
                    <li>
                        <label for="gender">gender:</label>
                        <select id="gender" name="gender">
                            <option value="<?php echo $gender; ?>"><?php echo $gender; ?></option>
                            <option value="0">Songo</option>
                            <option value="Em">Em</option>
                            <option value="Er">Er</option>
                        </select>
                    </li>
                    <li>
                        <label for="church">church:</label>
                        <input type="text" name="church" value="<?php echo $church; ?>" id="church" />
                    </li>
                    <li>
                        <label for="cellphone">phone:</label>
                        <input type="text" name="cellphone" value="<?php echo $cellphone; ?>" id="cellphone" />
                    </li>
                    <li>
                        <label for="comment">comment:</label>
                        <textarea name="comment" id="comment" rows="10" ><?php echo $comment; ?></textarea>
                    </li>
                    <li>
                        <label for="isActive">isActive:</label>
                        <input type="checkbox" name="isActive" value="1" id="isActive" <?php echo ($isActive==1 ? 'checked' : '');?>/>
                    </li>
                </ol>
                <input type="submit" name="submit" value="Submit" />
                <p>
                    <a href="users.php">Cancel</a>
                </p>
        </fieldset>
    </form>
</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php include ("Includes/footer.php"); ?>

