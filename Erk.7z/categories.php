<?php 
    require_once ("Includes/session.php"); 
    require_once ("Includes/simplecms-config.php"); 
    require_once  ("Includes/connectDB.php");
    include("Includes/header.php"); 
?>

<div id="main">
    <ul>
        <?php
            $statement = $databaseConnection->prepare("SELECT id, name, parent_id FROM categories");
            $statement->execute();

            if($statement->error)
            {
                die("Database query failed: " . $statement->error);
            }

            $statement->bind_result($categoryId, $name, $parentId);
            while($statement->fetch())
            {
                echo "<li><a href=\"/editcategory.php?id=$categoryId\">$name</a> --- $parentId</li>\n";
            }


            $temp_statement = category_tree();
            $temp_statement->bind_result($tempId, $tempName);
            while($temp_statement->fetch()) {
                echo "id=====" . $tempId . " name: ::::::::::::: " . $tempName . "<br>";
            }
        ?>
    </ul>

</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php 
    include ("Includes/footer.php");
 ?>