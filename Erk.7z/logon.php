<?php 
    require_once ("includes/session.php");
    require_once ("includes/simplecms-config.php"); 
    require_once ("includes/connectDB.php");

    if (isset($_POST['submit']))
    {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT id, username FROM users WHERE username = ? AND password = SHA(?) AND is_active = 1 LIMIT 1";
        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('ss', $username, $password);

        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows == 1)
        {
            $statement->bind_result($_SESSION['userid'], $_SESSION['username']);
            $statement->fetch();
            header ("Location: index.php");
        }
        else
        {
            echo "Username/password combination is incorrect.";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Нэвтрэх</title>
    <link href="/css/main.css" rel="stylesheet" type="text/css" />
    <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="login-logo">
                <img src="Images/logo_login.png" alt="WELCOME"/>
            </div>
            <form action="logon.php" method="post" class="form-horizontal">
                <div class="form-group">
                    <label class="control-label col-xs-2" for="username">Нэвтрэх нэр:</label>
                    <div class="col-xs-10">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Нэвтрэх нэр" />
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-xs-2" for="password">Нууц үг:</label>
                    <div class="col-xs-10">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Нууц үг:" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-offset-2 col-xs-10">
                        <input type="submit" class="btn btn-default" name="submit" value="Нэвтрэх" />
                        <a href="register.php" class="btn btn-default">Бүртгүүлэх</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>