<?php 
    require_once ("Includes/session.php");
    require_once ("Includes/simplecms-config.php"); 
    require_once ("Includes/connectDB.php");
    include("Includes/header.php"); 
    confirm_is_admin();

    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $thumbnail = $_POST['thumbnail'];
        $content = $_POST['content'];
        $categoryId = $_POST['categoryId'];
        $createdDate = date('Y-m-d H:i:s'); //current date
        $isActive = $_POST['isActive'];

        $query = "INSERT INTO posts (title, thumbnail, content, category_id, created_date, is_active) VALUES (?, ?, ?, ?, ?, ?)";

        $statement = $databaseConnection->prepare($query);
        $statement->bind_param('sssdsd', $title,$thumbnail, $content, $categoryId, $createdDate, $isActive);
        $statement->execute();
        $statement->store_result();

        if ($statement->error) {
            die('Database query failed: ' . $statement->error);
        }

        $creationWasSuccessful = $statement->affected_rows == 1 ? true : false;
        if ($creationWasSuccessful) {
            header ("Location: posts.php");
        }
        else {
            echo 'Failed adding new post';
        }
    }
?>
<div id="main">
    <h2>Add Post</h2>
        <form action="addpost.php" method="POST">
            <fieldset>
            <legend>Add post</legend>
            <ol>
                <li>
                    <label for="title">title:</label> 
                    <input type="text" name="title" value="" id="title" />
                </li>
                <li>
                    <label for="thumbnail">thumbnail:</label> 
                    <textarea name="thumbnail" id="thumbnail" rows="10"></textarea>
                </li>
                <li>
                    <label for="content">content:</label> 
                    <textarea name="content" id="content" rows="10"></textarea>
                </li>
                <li>
                    <label for="categoryId">categoryId:</label> 
                    <select name="categoryId" id="categoryId" >
                        <?php
                            $temp_statement = category_tree();
                            $temp_statement->bind_result($tempId, $tempName);
                            while($temp_statement->fetch()) {
                                //echo "id=====" . $tempId . " name: ::::::::::::: " . $tempName . "<br>";
                                echo "<option value=\"$tempId\">$tempName</option>";
                            }
                        ?>
                    </select>
                </li>
                <li>
                    <label for="isActive">isActive:</label> 
                    <input type="checkbox" name="isActive" value="1" id="isActive" checked />
                </li>
            </ol>
            <input type="submit" name="submit" value="Submit" />
            <p>
                <a href="index.php">Cancel</a>
            </p>
        </fieldset>
    </form>
</div>
</div> <!-- End of outer-wrapper which opens in header.php -->
<?php include ("Includes/footer.php"); ?>

